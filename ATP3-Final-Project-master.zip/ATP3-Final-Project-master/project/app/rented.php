<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rented extends Model
{
    protected $table = "rentedhouseinfo";
    public $timestamps = false;
}
