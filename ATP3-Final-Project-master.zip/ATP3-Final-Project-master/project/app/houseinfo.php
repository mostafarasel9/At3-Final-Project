<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class houseinfo extends Model
{
    protected $table = "houseinfos";
    public $timestamps = false;
	    protected $primaryKey = "houseid";
}
