<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manager extends Model
{
    protected $table = "managers";
    public $timestamps = false;
	protected $primaryKey = "userId";
}
