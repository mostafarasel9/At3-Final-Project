<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Manager Home page! Welcome to BTMS!</h1>&nbsp

	<a href="{{route('manager.list4')}}">View All</a> |
	<a href="/logout">Logout</a> 

</body>
</html>